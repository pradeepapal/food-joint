package com.ty.foodjoint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodJointApplicationTests {

	@Test
	void contextLoads() {
	}

}
